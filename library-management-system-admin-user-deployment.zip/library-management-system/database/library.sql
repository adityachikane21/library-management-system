CREATE DATABASE IF NOT EXISTS library_management;
USE library_management;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS members;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','user') DEFAULT 'user',
  member_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE books (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  author VARCHAR(150) NOT NULL,
  isbn VARCHAR(30) UNIQUE,
  category VARCHAR(100),
  total_copies INT NOT NULL DEFAULT 1,
  available_copies INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CHECK (total_copies > 0),
  CHECK (available_copies >= 0 AND available_copies <= total_copies)
);

CREATE TABLE members (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(150) UNIQUE NOT NULL,
  phone VARCHAR(30),
  course VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  book_id INT NOT NULL,
  member_id INT NOT NULL,
  issue_date DATE NOT NULL,
  due_date DATE NOT NULL,
  return_date DATE NULL,
  status ENUM('issued','returned') DEFAULT 'issued',
  fine DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,
  FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
  INDEX idx_transaction_status (status),
  INDEX idx_transaction_book (book_id),
  INDEX idx_transaction_member (member_id)
);

-- The backend creates/resets the demo admin password securely on startup.
INSERT INTO users(name,email,password_hash,role) VALUES
('Library Admin','admin@library.com','temporary-password-replaced-by-server','admin',NULL),
('Rahul Sharma','user@library.com','temporary-password-replaced-by-server','user',1);

INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES
('Clean Code','Robert C. Martin','9780132350884','Programming',5,5),
('The Pragmatic Programmer','Andrew Hunt','9780135957059','Programming',4,4),
('Database System Concepts','Silberschatz','9780078022159','Database',3,3),
('Computer Networks','Andrew S. Tanenbaum','9780132126953','Networking',4,4),
('Introduction to Algorithms','Cormen','9780262046305','Algorithms',3,3),
('Operating System Concepts','Silberschatz','9781119456339','Operating Systems',5,5);

INSERT INTO members(name,email,phone,course) VALUES
('Rahul Sharma','rahul@example.com','9876543210','BCA'),
('Priya Patel','priya@example.com','9876501234','BSc Computer Science'),
('Aman Verma','aman@example.com','9876512345','B.Tech');

INSERT INTO transactions(book_id,member_id,issue_date,due_date,status,fine)
VALUES (1,1,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'issued',0);
UPDATE books SET available_copies=available_copies-1 WHERE id=1;
