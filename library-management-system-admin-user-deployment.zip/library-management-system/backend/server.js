import express from "express";
import cors from "cors";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import pool from "./config/db.js";
import { auth } from "./middleware/auth.js";

const adminOnly = (req, res, next) => req.user?.role === "admin" ? next() : res.status(403).json({ message: "Admin access required" });

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = Number(process.env.PORT || 5000);
const FINE_PER_DAY = Number(process.env.FINE_PER_DAY || 5);
const JWT_SECRET = process.env.JWT_SECRET || "dev-only-change-this-secret";

app.use(cors({ origin: true, credentials: false }));
app.use(express.json());

const asyncHandler = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const clean = value => String(value ?? "").trim();
const positiveInt = value => Number.isInteger(Number(value)) && Number(value) > 0;

app.get("/api/health", asyncHandler(async (req, res) => {
  await pool.query("SELECT 1");
  res.json({ status: "ok", database: "connected", finePerDay: FINE_PER_DAY });
}));

app.post("/api/auth/login", asyncHandler(async (req, res) => {
  const email = clean(req.body.email).toLowerCase();
  const password = String(req.body.password ?? "");
  if (!email || !password) return res.status(400).json({ message: "Email and password are required" });

  const [rows] = await pool.query("SELECT * FROM users WHERE email = ? LIMIT 1", [email]);
  const user = rows[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    return res.status(401).json({ message: "Invalid email or password" });
  }
  const token = jwt.sign(
    { id: user.id, name: user.name, role: user.role },
    JWT_SECRET,
    { expiresIn: "8h" }
  );
  res.json({ token, user: { id: user.id, name: user.name, email: user.email, role: user.role } });
}));

app.get("/api/user/me", auth, asyncHandler(async (req, res) => {
  const [[user]] = await pool.query("SELECT id,name,email,role,member_id FROM users WHERE id=?", [req.user.id]);
  if (!user) return res.status(404).json({ message: "User not found" });
  let loans = [];
  if (user.member_id) {
    [loans] = await pool.query(`SELECT t.id,b.title,t.issue_date,t.due_date,t.return_date,t.status,t.fine FROM transactions t JOIN books b ON b.id=t.book_id WHERE t.member_id=? ORDER BY t.id DESC`, [user.member_id]);
  }
  res.json({ user, loans });
}));

app.get("/api/dashboard", auth, asyncHandler(async (req, res) => {
  const [[books]] = await pool.query("SELECT COUNT(*) total FROM books");
  const [[members]] = await pool.query("SELECT COUNT(*) total FROM members");
  const [[issued]] = await pool.query("SELECT COUNT(*) total FROM transactions WHERE status='issued'");
  const [[available]] = await pool.query("SELECT COALESCE(SUM(available_copies),0) total FROM books");
  const [[fines]] = await pool.query("SELECT COALESCE(SUM(fine),0) total FROM transactions");
  const [recent] = await pool.query(`
    SELECT t.id, b.title, m.name member_name, t.issue_date, t.due_date, t.return_date, t.status, t.fine
    FROM transactions t
    JOIN books b ON b.id=t.book_id
    JOIN members m ON m.id=t.member_id
    ORDER BY t.id DESC LIMIT 8
  `);
  res.json({ stats: { books: Number(books.total), members: Number(members.total), issued: Number(issued.total), available: Number(available.total), fines: Number(fines.total) }, recent });
}));

app.get("/api/books", auth, asyncHandler(async (req, res) => {
  const q = `%${clean(req.query.q)}%`;
  const [rows] = await pool.query("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ? OR category LIKE ? ORDER BY id DESC", [q, q, q, q]);
  res.json(rows);
}));

app.post("/api/books", auth, asyncHandler(async (req, res) => {
  const title = clean(req.body.title), author = clean(req.body.author), isbn = clean(req.body.isbn) || null, category = clean(req.body.category) || null, total = Number(req.body.total_copies);
  if (!title || !author || !positiveInt(total)) return res.status(400).json({ message: "Title, author and a valid quantity are required" });
  const [r] = await pool.query("INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES(?,?,?,?,?,?)", [title, author, isbn, category, total, total]);
  res.status(201).json({ id: r.insertId, message: "Book added successfully" });
}));

app.put("/api/books/:id", auth, asyncHandler(async (req, res) => {
  const title = clean(req.body.title), author = clean(req.body.author), isbn = clean(req.body.isbn) || null, category = clean(req.body.category) || null, requestedTotal = Number(req.body.total_copies);
  if (!title || !author || !positiveInt(requestedTotal)) return res.status(400).json({ message: "Title, author and a valid quantity are required" });
  const [[book]] = await pool.query("SELECT * FROM books WHERE id=?", [req.params.id]);
  if (!book) return res.status(404).json({ message: "Book not found" });
  const issued = Number(book.total_copies) - Number(book.available_copies);
  if (requestedTotal < issued) return res.status(400).json({ message: `Total copies cannot be less than currently issued copies (${issued})` });
  await pool.query("UPDATE books SET title=?,author=?,isbn=?,category=?,total_copies=?,available_copies=? WHERE id=?", [title, author, isbn, category, requestedTotal, requestedTotal - issued, req.params.id]);
  res.json({ message: "Book updated successfully" });
}));

app.delete("/api/books/:id", auth, asyncHandler(async (req, res) => {
  const [[book]] = await pool.query("SELECT id FROM books WHERE id=?", [req.params.id]);
  if (!book) return res.status(404).json({ message: "Book not found" });
  const [[active]] = await pool.query("SELECT COUNT(*) total FROM transactions WHERE book_id=? AND status='issued'", [req.params.id]);
  if (Number(active.total) > 0) return res.status(400).json({ message: "Cannot delete a book that is currently issued" });
  await pool.query("DELETE FROM books WHERE id=?", [req.params.id]);
  res.json({ message: "Book deleted successfully" });
}));

app.get("/api/members", auth, asyncHandler(async (req, res) => {
  const q = `%${clean(req.query.q)}%`;
  const [rows] = await pool.query("SELECT * FROM members WHERE name LIKE ? OR email LIKE ? OR phone LIKE ? OR course LIKE ? ORDER BY id DESC", [q, q, q, q]);
  res.json(rows);
}));

app.post("/api/members", auth, asyncHandler(async (req, res) => {
  const name = clean(req.body.name), email = clean(req.body.email).toLowerCase(), phone = clean(req.body.phone), course = clean(req.body.course);
  if (!name || !email) return res.status(400).json({ message: "Name and email are required" });
  const [r] = await pool.query("INSERT INTO members(name,email,phone,course) VALUES(?,?,?,?)", [name, email, phone || null, course || null]);
  res.status(201).json({ id: r.insertId, message: "Member added successfully" });
}));

app.put("/api/members/:id", auth, asyncHandler(async (req, res) => {
  const name = clean(req.body.name), email = clean(req.body.email).toLowerCase(), phone = clean(req.body.phone), course = clean(req.body.course);
  if (!name || !email) return res.status(400).json({ message: "Name and email are required" });
  const [[member]] = await pool.query("SELECT id FROM members WHERE id=?", [req.params.id]);
  if (!member) return res.status(404).json({ message: "Member not found" });
  await pool.query("UPDATE members SET name=?,email=?,phone=?,course=? WHERE id=?", [name, email, phone || null, course || null, req.params.id]);
  res.json({ message: "Member updated successfully" });
}));

app.delete("/api/members/:id", auth, asyncHandler(async (req, res) => {
  const [[active]] = await pool.query("SELECT COUNT(*) total FROM transactions WHERE member_id=? AND status='issued'", [req.params.id]);
  if (Number(active.total) > 0) return res.status(400).json({ message: "Cannot delete a member with an active issued book" });
  const [r] = await pool.query("DELETE FROM members WHERE id=?", [req.params.id]);
  if (!r.affectedRows) return res.status(404).json({ message: "Member not found" });
  res.json({ message: "Member deleted successfully" });
}));

app.get("/api/transactions", auth, asyncHandler(async (req, res) => {
  const status = clean(req.query.status), q = `%${clean(req.query.q)}%`;
  const params = [q, q];
  let where = "WHERE (b.title LIKE ? OR m.name LIKE ?)";
  if (status === "issued" || status === "returned") { where += " AND t.status=?"; params.push(status); }
  const [rows] = await pool.query(`SELECT t.*, b.title, m.name member_name FROM transactions t JOIN books b ON b.id=t.book_id JOIN members m ON m.id=t.member_id ${where} ORDER BY t.id DESC`, params);
  res.json(rows);
}));

app.post("/api/transactions", auth, asyncHandler(async (req, res) => {
  const bookId = Number(req.body.book_id), memberId = Number(req.body.member_id), dueDate = clean(req.body.due_date);
  if (!positiveInt(bookId) || !positiveInt(memberId) || !/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) return res.status(400).json({ message: "Book, member and a valid due date are required" });
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[book]] = await conn.query("SELECT id, available_copies FROM books WHERE id=? FOR UPDATE", [bookId]);
    if (!book) throw new Error("Book not found");
    if (Number(book.available_copies) < 1) throw new Error("Book is not available");
    const [[member]] = await conn.query("SELECT id FROM members WHERE id=?", [memberId]);
    if (!member) throw new Error("Member not found");
    const [[duplicate]] = await conn.query("SELECT id FROM transactions WHERE book_id=? AND member_id=? AND status='issued'", [bookId, memberId]);
    if (duplicate) throw new Error("This member already has this book issued");
    await conn.query("UPDATE books SET available_copies=available_copies-1 WHERE id=?", [bookId]);
    await conn.query("INSERT INTO transactions(book_id,member_id,issue_date,due_date,status,fine) VALUES(?,?,CURDATE(),?,'issued',0)", [bookId, memberId, dueDate]);
    await conn.commit();
    res.status(201).json({ message: "Book issued successfully" });
  } catch (e) { await conn.rollback(); res.status(400).json({ message: e.message }); } finally { conn.release(); }
}));

app.put("/api/transactions/:id/return", auth, asyncHandler(async (req, res) => {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [[t]] = await conn.query("SELECT * FROM transactions WHERE id=? FOR UPDATE", [req.params.id]);
    if (!t) throw new Error("Transaction not found");
    if (t.status === "returned") throw new Error("Transaction is already returned");
    const [[calc]] = await conn.query("SELECT GREATEST(DATEDIFF(CURDATE(), ?),0) days", [t.due_date]);
    const fine = Number(calc.days) * FINE_PER_DAY;
    await conn.query("UPDATE transactions SET return_date=CURDATE(),status='returned',fine=? WHERE id=?", [fine, t.id]);
    await conn.query("UPDATE books SET available_copies=available_copies+1 WHERE id=?", [t.book_id]);
    await conn.commit();
    res.json({ message: "Book returned successfully", fine, overdueDays: Number(calc.days) });
  } catch (e) { await conn.rollback(); res.status(400).json({ message: e.message }); } finally { conn.release(); }
}));

async function ensureSchema() {
  await pool.query(`CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,password_hash VARCHAR(255) NOT NULL,role ENUM('admin','user') DEFAULT 'user',member_id INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await pool.query(`UPDATE users SET role='admin' WHERE role='librarian'`);
  await pool.query(`ALTER TABLE users MODIFY COLUMN role ENUM('admin','user') DEFAULT 'user'`);
  await pool.query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS member_id INT NULL`);
  await pool.query(`CREATE TABLE IF NOT EXISTS books (id INT AUTO_INCREMENT PRIMARY KEY,title VARCHAR(200) NOT NULL,author VARCHAR(150) NOT NULL,isbn VARCHAR(30) UNIQUE,category VARCHAR(100),total_copies INT NOT NULL DEFAULT 1,available_copies INT NOT NULL DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS members (id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL,email VARCHAR(150) UNIQUE NOT NULL,phone VARCHAR(30),course VARCHAR(100),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)`);
  await pool.query(`CREATE TABLE IF NOT EXISTS transactions (id INT AUTO_INCREMENT PRIMARY KEY,book_id INT NOT NULL,member_id INT NOT NULL,issue_date DATE NOT NULL,due_date DATE NOT NULL,return_date DATE NULL,status ENUM('issued','returned') DEFAULT 'issued',fine DECIMAL(10,2) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE,FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,INDEX idx_transaction_status (status),INDEX idx_transaction_book (book_id),INDEX idx_transaction_member (member_id))`);
}

async function ensureDemoData() {
  const email = "admin@library.com";
  const passwordHash = await bcrypt.hash("admin123", 10);
  const [[existing]] = await pool.query("SELECT id FROM users WHERE email=?", [email]);
  if (existing) await pool.query("UPDATE users SET password_hash=?,name='Library Admin',role='admin' WHERE email=?", [passwordHash, email]);
  else await pool.query("INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,'admin')", ["Library Admin", email, passwordHash]);
  const userPasswordHash = await bcrypt.hash("user123", 10);
  const [[demoMember]] = await pool.query("SELECT id FROM members WHERE email=? LIMIT 1", ["rahul@example.com"]);
  const [[demoUser]] = await pool.query("SELECT id FROM users WHERE email=?", ["user@library.com"]);
  if (demoUser) await pool.query("UPDATE users SET password_hash=?,name='Rahul Sharma',role='user',member_id=? WHERE email=?", [userPasswordHash, demoMember?.id || null, "user@library.com"]);
  else await pool.query("INSERT INTO users(name,email,password_hash,role,member_id) VALUES(?,?,?,'user',?)", ["Rahul Sharma","user@library.com",userPasswordHash,demoMember?.id || null]);

  const [[bookCount]] = await pool.query("SELECT COUNT(*) total FROM books");
  if (Number(bookCount.total) === 0) {
    const books = [
      ["Clean Code","Robert C. Martin","9780132350884","Programming",5],
      ["The Pragmatic Programmer","Andrew Hunt","9780135957059","Programming",4],
      ["Database System Concepts","Silberschatz","9780078022159","Database",3],
      ["Computer Networks","Andrew S. Tanenbaum","9780132126953","Networking",4],
      ["Introduction to Algorithms","Cormen","9780262046305","Algorithms",3],
      ["Operating System Concepts","Silberschatz","9781119456339","Operating Systems",5]
    ];
    for (const b of books) await pool.query("INSERT INTO books(title,author,isbn,category,total_copies,available_copies) VALUES(?,?,?,?,?,?)", [...b, b[4]]);
  }
  const [[memberCount]] = await pool.query("SELECT COUNT(*) total FROM members");
  if (Number(memberCount.total) === 0) {
    await pool.query("INSERT INTO members(name,email,phone,course) VALUES ?", [[
      ["Rahul Sharma","rahul@example.com","9876543210","BCA"],
      ["Priya Patel","priya@example.com","9876501234","BSc Computer Science"],
      ["Aman Verma","aman@example.com","9876512345","B.Tech"]
    ]]);
  }
  const [[rahulMember]] = await pool.query("SELECT id FROM members WHERE email=? LIMIT 1", ["rahul@example.com"]);
  await pool.query("UPDATE users SET member_id=? WHERE email=?", [rahulMember?.id || null, "user@library.com"]);
  const [[txCount]] = await pool.query("SELECT COUNT(*) total FROM transactions");
  if (Number(txCount.total) === 0) {
    const [[book]] = await pool.query("SELECT id FROM books ORDER BY id LIMIT 1");
    const [[member]] = await pool.query("SELECT id FROM members ORDER BY id LIMIT 1");
    await pool.query("INSERT INTO transactions(book_id,member_id,issue_date,due_date,status,fine) VALUES(?,?,CURDATE(),DATE_ADD(CURDATE(),INTERVAL 14 DAY),'issued',0)", [book.id, member.id]);
    await pool.query("UPDATE books SET available_copies=available_copies-1 WHERE id=?", [book.id]);
  }
}

app.use(express.static(path.join(__dirname, "public")));
app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use((err, req, res, next) => {
  console.error(err);
  if (err?.code === "ER_DUP_ENTRY") return res.status(409).json({ message: "A record with this unique value already exists" });
  res.status(500).json({ message: "Server error", detail: process.env.NODE_ENV === "development" ? err.message : undefined });
});

async function start() {
  try {
    await pool.query("SELECT 1");
    await ensureSchema();
    await ensureDemoData();
    app.listen(PORT, "0.0.0.0", () => console.log(`Library Management System running on port ${PORT}`));
  } catch (error) {
    console.error("Database connection/schema setup failed.");
    console.error(error);
    process.exit(1);
  }
}

start();
